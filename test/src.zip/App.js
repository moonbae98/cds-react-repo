import './App.css';
import Main from './listtest/Main';

function App() {
  return (
    <div>
      <Main />
    </div>
  );
}

export default App;
